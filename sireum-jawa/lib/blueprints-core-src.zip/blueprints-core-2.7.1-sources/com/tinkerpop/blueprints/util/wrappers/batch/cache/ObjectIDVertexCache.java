package com.tinkerpop.blueprints.util.wrappers.batch.cache;


/**
 * (c) Matthias Broecheler (me@matthiasb.com)
 */

public class ObjectIDVertexCache extends AbstractIDVertexCache { }