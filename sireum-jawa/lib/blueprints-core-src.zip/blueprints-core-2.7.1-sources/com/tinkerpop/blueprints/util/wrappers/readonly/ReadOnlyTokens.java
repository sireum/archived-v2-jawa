package com.tinkerpop.blueprints.util.wrappers.readonly;

/**
 * @author Marko A. Rodriguez (http://markorodriguez.com)
 */
public class ReadOnlyTokens {

    public final static String MUTATE_ERROR_MESSAGE = "It is not possible to mutate a ReadOnlyGraph";
}
